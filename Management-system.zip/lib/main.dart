import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

// ---------------------------------------------------------------
// CONFIG
// ---------------------------------------------------------------
const String baseUrl = 'https://management-system-g467.onrender.com';

// ---------------------------------------------------------------
// API HELPER
// ---------------------------------------------------------------
class ApiException implements Exception {
  final String message;
  final int status;
  ApiException(this.message, this.status);
}

class Api {
  static String? token;
  static Map<String, dynamic>? user;

  static Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };

  static dynamic _handle(http.Response r) {
    dynamic body;
    try {
      body = jsonDecode(utf8.decode(r.bodyBytes));
    } catch (_) {
      body = null;
    }
    if (r.statusCode >= 200 && r.statusCode < 300) return body;
    String msg = 'Error ${r.statusCode}';
    if (body is Map && body['detail'] != null) {
      final d = body['detail'];
      msg = d is String ? d : 'Invalid input';
    }
    throw ApiException(msg, r.statusCode);
  }

  static const _timeout =
      Duration(seconds: 60); // Render free tier can be slow to wake up

  static Future<dynamic> get(String path) async => _handle(await http
      .get(Uri.parse('$baseUrl$path'), headers: _headers)
      .timeout(_timeout));

  static Future<dynamic> post(String path,
          [Map<String, dynamic>? body]) async =>
      _handle(await http
          .post(Uri.parse('$baseUrl$path'),
              headers: _headers, body: jsonEncode(body ?? {}))
          .timeout(_timeout));

  static Future<dynamic> put(String path, Map<String, dynamic> body) async =>
      _handle(await http
          .put(Uri.parse('$baseUrl$path'),
              headers: _headers, body: jsonEncode(body))
          .timeout(_timeout));

  static Future<dynamic> delete(String path) async => _handle(await http
      .delete(Uri.parse('$baseUrl$path'), headers: _headers)
      .timeout(_timeout));

  static Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    token = p.getString('token');
    final u = p.getString('user');
    user = u == null ? null : Map<String, dynamic>.from(jsonDecode(u));
  }

  static Future<void> save(String t, Map<String, dynamic> u) async {
    token = t;
    user = u;
    final p = await SharedPreferences.getInstance();
    await p.setString('token', t);
    await p.setString('user', jsonEncode(u));
  }

  static Future<void> clear() async {
    token = null;
    user = null;
    final p = await SharedPreferences.getInstance();
    await p.remove('token');
    await p.remove('user');
  }
}

// ---------------------------------------------------------------
// BACKGROUND NOTIFICATIONS (runs even when the app is closed / screen locked)
// ---------------------------------------------------------------
const String _svcChannelId = 'team_bg';
const String _alertChannelId = 'team_alerts';

const _initSettings = InitializationSettings(
    android: AndroidInitializationSettings('@mipmap/ic_launcher'));

String notifTitle(String body) {
  final b = body.toLowerCase();
  if (b.contains('video') && b.contains('assign'))
    return '🚨 New Video Assigned!';
  if (b.contains('reminder') || b.contains('ping')) return '⚠️ Admin Reminder';
  return '📢 Global Announcement';
}

Future<void> _showAlert(
    FlutterLocalNotificationsPlugin plugin, int id, String title, String body) {
  return plugin.show(
    id,
    title,
    body,
    const NotificationDetails(
      android: AndroidNotificationDetails(
        _alertChannelId,
        'Alerts',
        channelDescription: 'Messages and video assignments',
        importance: Importance.max,
        priority: Priority.high,
      ),
    ),
  );
}

/// Marks whether the app screen is open, so the background service
/// doesn't double-notify while the in-app dialog is already showing.
class _LifecycleBridge extends WidgetsBindingObserver {
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('app_fg', state == AppLifecycleState.resumed);
  }
}

Future<void> initializeBackgroundNotificationService() async {
  try {
    final plugin = FlutterLocalNotificationsPlugin();
    await plugin.initialize(_initSettings);
    final android = plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    // channel for the persistent "service running" notification (must exist before start)
    await android?.createNotificationChannel(const AndroidNotificationChannel(
      _svcChannelId,
      'Background sync',
      description: 'Keeps the app listening for new messages',
      importance: Importance.low,
    ));
    await android?.requestNotificationsPermission();

    final p = await SharedPreferences.getInstance();
    await p.setBool('app_fg', true);
    WidgetsBinding.instance.addObserver(_LifecycleBridge());

    final service = FlutterBackgroundService();
    await service.configure(
      androidConfiguration: AndroidConfiguration(
        onStart: onBackgroundStart,
        autoStart: true,
        isForegroundMode: true,
        notificationChannelId: _svcChannelId,
        initialNotificationTitle: 'Team Availability',
        initialNotificationContent: 'Listening for updates',
        foregroundServiceNotificationId: 888,
      ),
      iosConfiguration: IosConfiguration(autoStart: false),
    );
    if (!await service.isRunning()) await service.startService();
  } catch (_) {
    // never let notification setup crash the app
  }
}

@pragma('vm:entry-point')
void onBackgroundStart(ServiceInstance service) async {
  DartPluginRegistrant.ensureInitialized();
  final plugin = FlutterLocalNotificationsPlugin();
  await plugin.initialize(_initSettings);
  service.on('stop').listen((_) => service.stopSelf());

  bool busy = false;
  Timer.periodic(const Duration(seconds: 15), (_) async {
    if (busy) return; // Render cold starts can take a while
    busy = true;
    try {
      await _backgroundPoll(plugin);
    } catch (_) {}
    busy = false;
  });
}

Future<void> _backgroundPoll(FlutterLocalNotificationsPlugin plugin) async {
  final p = await SharedPreferences.getInstance();
  await p
      .reload(); // pick up token / foreground flag written by the main isolate
  await Api.load();
  if (Api.token == null || Api.user?['role'] != 'user') return;
  final uid = Api.user?['id'];
  final inForeground = p.getBool('app_fg') ?? false;

  // ---- messages ----
  final msgKey = 'bg_msg_$uid';
  final r = await Api.get('/me/messages');
  final list =
      (r['messages'] as List).map((e) => Map<String, dynamic>.from(e)).toList();
  final latest = (r['latest_id'] as int?) ?? 0;
  final last = p.getInt(msgKey);
  if (last == null) {
    await p.setInt(msgKey, latest); // first run: don't replay old messages
  } else if (latest > last) {
    await p.setInt(msgKey, latest);
    if (!inForeground) {
      final fresh =
          list.where((m) => (m['id'] as int) > last).toList().reversed;
      for (final m in fresh) {
        final body = (m['body'] ?? '').toString();
        await _showAlert(plugin, m['id'] as int, notifTitle(body), body);
      }
    }
  }

  // ---- video assignment ----
  final vidKey = 'bg_vid_$uid';
  final v = await Api.get('/me/video');
  final a = v['assignment'];
  if (a == null) {
    await p.remove(vidKey);
  } else if (a['status'] == 'assigned') {
    final key = '${a['server']}|${a['part_label']}';
    if (p.getString(vidKey) != key) {
      await p.setString(vidKey, key);
      if (!inForeground) {
        await _showAlert(
            plugin,
            900000 + key.hashCode.abs() % 90000,
            '🚨 New Video Assigned!',
            'Server: ${a['server']}\nTime: ${a['part_label']}');
      }
    }
  }
}

// ---------------------------------------------------------------
// SMALL HELPERS
// ---------------------------------------------------------------
const _months = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec'
];
const _days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

String apiDate(DateTime d) =>
    '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

String prettyDate(DateTime d) =>
    '${_days[d.weekday - 1]}, ${d.day} ${_months[d.month - 1]}';

bool isSameDay(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;

void toast(BuildContext c, String m) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

String errMsg(Object e) => e is ApiException
    ? e.message
    : 'Could not connect. Check internet and try again.';

Color statusColor(String ds) {
  switch (ds) {
    case 'available':
      return Colors.green;
    case 'unavailable':
      return Colors.red;
    case 'working_on_video':
      return Colors.amber.shade800;
    case 'video_assigned':
      return Colors.indigo;
    case 'available_ended':
    case 'unavailable_ended':
      return Colors.grey;
    default:
      return Colors.blueGrey;
  }
}

String statusLabel(Map m) {
  final String ds = m['display_status'] as String;
  final until = m['available_until_label'];
  switch (ds) {
    case 'available':
      return until != null ? 'Available till $until' : 'Available';
    case 'available_ended':
      return 'Availability ended ($until)';
    case 'unavailable':
      return until != null
          ? 'Unavailable till $until'
          : 'Unavailable (all day)';
    case 'unavailable_ended':
      return 'Unavailable time ended ($until)';
    case 'working_on_video':
      return 'Working on a video';
    case 'video_assigned':
      return 'Video assigned - not started';
    default:
      return 'Not responded yet';
  }
}

Future<int> getSeen() async {
  final p = await SharedPreferences.getInstance();
  return p.getInt('seen_${Api.user?['id']}') ?? 0;
}

Future<void> setSeen(int id) async {
  final p = await SharedPreferences.getInstance();
  await p.setInt('seen_${Api.user?['id']}', id);
}

// ---------------------------------------------------------------
// APP ENTRY
// ---------------------------------------------------------------
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Api.load();
  await initializeBackgroundNotificationService();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Team Availability',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: const Root(),
    );
  }
}

class Root extends StatefulWidget {
  const Root({super.key});

  @override
  State<Root> createState() => _RootState();
}

class _RootState extends State<Root> {
  Future<void> logout() async {
    await Api.clear();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (Api.token == null) return LoginPage(onDone: () => setState(() {}));
    if (Api.user?['role'] == 'admin') return AdminHome(onLogout: logout);
    return UserHome(onLogout: logout);
  }
}

// ---------------------------------------------------------------
// LOGIN
// ---------------------------------------------------------------
class LoginPage extends StatefulWidget {
  final VoidCallback onDone;
  const LoginPage({super.key, required this.onDone});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final userC = TextEditingController();
  final passC = TextEditingController();
  bool loading = false;
  String? error;

  Future<void> login() async {
    if (userC.text.trim().isEmpty || passC.text.isEmpty) {
      setState(() => error = 'Enter username and password');
      return;
    }
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final r = await Api.post(
          '/login', {'username': userC.text.trim(), 'password': passC.text});
      await Api.save(r['token'], Map<String, dynamic>.from(r['user']));
      widget.onDone();
    } catch (e) {
      if (mounted) setState(() => error = errMsg(e));
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.event_available,
                    size: 72, color: Colors.indigo),
                const SizedBox(height: 12),
                const Text('Team Availability',
                    style:
                        TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                const SizedBox(height: 32),
                TextField(
                  controller: userC,
                  autocorrect: false,
                  textInputAction: TextInputAction.next,
                  decoration: const InputDecoration(
                      labelText: 'Username', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: passC,
                  obscureText: true,
                  onSubmitted: (_) => login(),
                  decoration: const InputDecoration(
                      labelText: 'Password', border: OutlineInputBorder()),
                ),
                if (error != null) ...[
                  const SizedBox(height: 12),
                  Text(error!, style: const TextStyle(color: Colors.red)),
                ],
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: FilledButton(
                    onPressed: loading ? null : login,
                    child: loading
                        ? const SizedBox(
                            height: 22,
                            width: 22,
                            child: CircularProgressIndicator(
                                strokeWidth: 2, color: Colors.white))
                        : const Text('Log in', style: TextStyle(fontSize: 17)),
                  ),
                ),
                if (loading) ...[
                  const SizedBox(height: 12),
                  const Text('First login may take up to a minute...',
                      style: TextStyle(color: Colors.grey)),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------
// USER SCREEN
// ---------------------------------------------------------------
class UserHome extends StatefulWidget {
  final VoidCallback onLogout;
  const UserHome({super.key, required this.onLogout});

  @override
  State<UserHome> createState() => _UserHomeState();
}

class _UserHomeState extends State<UserHome> {
  DateTime date = DateTime.now();
  Map<String, dynamic>? current; // my availability for the chosen date
  Map<String, dynamic>? video; // my active video assignment (or null)
  String? status;
  String chip = 'all'; // all | 60 | 120 | custom
  TimeOfDay? custom;
  bool loading = true;
  bool saving = false;
  Timer? timer;

  // messages
  List<Map<String, dynamic>> msgs = [];
  int seenId = 0;
  int notifiedId = 0;
  int unread = 0;
  bool firstPoll = true;

  bool get isToday => isSameDay(date, DateTime.now());

  // An assigned or in-progress video locks the normal availability switches.
  bool get videoLocked => video != null;

  @override
  void initState() {
    super.initState();
    () async {
      seenId = await getSeen();
      await load();
    }();
    timer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (mounted) load(quiet: true);
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> load({bool quiet = false}) async {
    if (!quiet) setState(() => loading = true);
    try {
      final r = Map<String, dynamic>.from(
          await Api.get('/me/availability?date=${apiDate(date)}'));
      final oldStatus = current?['status'];
      current = r;
      if (!quiet || r['status'] != oldStatus) status = r['status'] as String?;
      final v = await Api.get('/me/video');
      video = v['assignment'] == null
          ? null
          : Map<String, dynamic>.from(v['assignment']);
      await pollMessages();
    } catch (e) {
      if (!quiet && mounted) toast(context, errMsg(e));
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> pollMessages() async {
    final r = await Api.get('/me/messages');
    final list = (r['messages'] as List)
        .map((e) => Map<String, dynamic>.from(e))
        .toList(); // newest first
    final latest = (r['latest_id'] as int?) ?? 0;
    msgs = list;
    unread = list.where((m) => (m['id'] as int) > seenId).length;
    if (firstPoll) {
      notifiedId = latest;
      firstPoll = false;
    } else if (latest > notifiedId) {
      final fresh = list
          .where((m) => (m['id'] as int) > notifiedId)
          .toList()
          .reversed
          .toList();
      notifiedId = latest;
      if (fresh.isNotEmpty && mounted) showNew(fresh, latest);
    }
  }

  Future<void> showNew(List<Map<String, dynamic>> fresh, int latest) async {
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Row(children: [
          Icon(Icons.notifications_active, color: Colors.indigo),
          SizedBox(width: 8),
          Text('New message'),
        ]),
        content: Text(fresh.map((m) => m['body']).join('\n\n')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('OK'))
        ],
      ),
    );
    seenId = latest;
    await setSeen(latest);
    if (mounted) setState(() => unread = 0);
  }

  Future<void> openMessages() async {
    await Navigator.push(
        context, MaterialPageRoute(builder: (_) => const MessagesPage()));
    seenId = await getSeen();
    if (mounted) {
      setState(
          () => unread = msgs.where((m) => (m['id'] as int) > seenId).length);
    }
  }

  Future<void> pickDate() async {
    final now = DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: date,
      firstDate: DateTime(now.year, now.month, now.day),
      lastDate: now.add(const Duration(days: 60)),
    );
    if (d != null) {
      date = d;
      chip = 'all';
      custom = null;
      load();
    }
  }

  Future<void> save() async {
    if (videoLocked) {
      toast(context, 'Finish your video first');
      return;
    }
    if (status == null) {
      toast(context, 'Pick a status first');
      return;
    }
    final body = <String, dynamic>{'date': apiDate(date), 'status': status};
    if (status == 'available' || status == 'unavailable') {
      if (chip == 'custom') {
        if (custom == null) {
          toast(context, 'Pick the custom time');
          return;
        }
        final hh = custom!.hour.toString().padLeft(2, '0');
        final mm = custom!.minute.toString().padLeft(2, '0');
        body['available_until'] = '${apiDate(date)}T$hh:$mm:00+05:30'; // IST
      } else if (chip != 'all') {
        body['available_for_minutes'] = int.parse(chip);
      }
    }
    setState(() => saving = true);
    try {
      final r = await Api.put('/me/availability', body);
      current = Map<String, dynamic>.from(r);
      if (mounted) toast(context, 'Saved');
    } catch (e) {
      if (mounted) toast(context, errMsg(e));
    }
    if (mounted) setState(() => saving = false);
  }

  Future<void> extend() async {
    try {
      final r = await Api.post('/me/availability/extend', {'minutes': 60});
      current = Map<String, dynamic>.from(r);
      if (mounted) toast(context, 'Extended by 1 hour');
    } catch (e) {
      if (mounted) toast(context, errMsg(e));
    }
    if (mounted) setState(() {});
  }

  Future<void> startVideo() async {
    try {
      await Api.post('/me/video/start');
      if (mounted) toast(context, 'Video started');
      await load(quiet: true);
    } catch (e) {
      if (mounted) toast(context, errMsg(e));
    }
  }

  Future<void> completeVideo() async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Video completed'),
        content: const Text('Are you still available?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('No')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Yes')),
        ],
      ),
    );
    if (yes == null) return;
    try {
      await Api.post('/me/video/complete', {'still_available': yes});
      if (mounted)
        toast(
            context,
            yes
                ? 'Done. You are back in the queue'
                : 'Done. Marked unavailable');
      await load(quiet: true);
    } catch (e) {
      if (mounted) toast(context, errMsg(e));
    }
  }

  Widget statusBtn(String key, String label, IconData icon, Color color) {
    final sel = status == key;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: SizedBox(
        height: 60,
        width: double.infinity,
        child: ElevatedButton.icon(
          onPressed: videoLocked ? null : () => setState(() => status = key),
          icon: Icon(icon),
          label: Text(label, style: const TextStyle(fontSize: 18)),
          style: ElevatedButton.styleFrom(
            backgroundColor: sel ? color : color.withOpacity(0.12),
            foregroundColor: sel ? Colors.white : color,
            elevation: sel ? 2 : 0,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
      ),
    );
  }

  Widget timeChips() {
    final options = <List<String>>[
      ['all', 'All day'],
      if (isToday) ['60', '1 hour'],
      if (isToday) ['120', '2 hours'],
    ];
    return Wrap(
      spacing: 8,
      runSpacing: 4,
      children: [
        for (final o in options)
          ChoiceChip(
            label: Text(o[1]),
            selected: chip == o[0],
            onSelected: (_) => setState(() => chip = o[0]),
          ),
        ChoiceChip(
          avatar: const Icon(Icons.access_time, size: 18),
          label: Text(custom == null
              ? 'Custom time'
              : 'Till ${custom!.format(context)}'),
          selected: chip == 'custom',
          onSelected: (_) async {
            final t = await showTimePicker(
                context: context,
                initialTime: TimeOfDay.fromDateTime(DateTime.now()));
            if (t != null) {
              setState(() {
                custom = t;
                chip = 'custom';
              });
            }
          },
        ),
      ],
    );
  }

  Widget videoCard() {
    final v = video!;
    final assigned = v['status'] == 'assigned';
    final note = (v['note'] ?? '') as String;
    return Card(
      color: Colors.indigo.withOpacity(0.08),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              const Icon(Icons.videocam, color: Colors.indigo),
              const SizedBox(width: 8),
              Text(assigned ? 'Video assigned to you' : 'Video in progress',
                  style: const TextStyle(
                      fontSize: 17, fontWeight: FontWeight.bold)),
            ]),
            const SizedBox(height: 8),
            Text('Server: ${v['server']}'),
            Text('Time: ${v['part_label']}'),
            if (note.isNotEmpty) Text('Note: $note'),
            if (assigned) ...[
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: FilledButton.icon(
                  onPressed: startVideo,
                  icon: const Icon(Icons.play_arrow),
                  label: const Text('Video started',
                      style: TextStyle(fontSize: 17)),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final canExtend = isToday &&
        current != null &&
        current!['status'] == 'available' &&
        current!['available_until'] != null;
    final canComplete = (video != null && video!['status'] == 'started') ||
        (isToday && current?['status'] == 'working_on_video');

    return Scaffold(
      appBar: AppBar(
        title: Text('Hi, ${Api.user?['name'] ?? ''}'),
        actions: [
          IconButton(
            tooltip: 'Messages',
            onPressed: openMessages,
            icon: Badge(
              isLabelVisible: unread > 0,
              label: Text('$unread'),
              child: const Icon(Icons.chat_bubble_outline),
            ),
          ),
          IconButton(
              icon: const Icon(Icons.logout),
              tooltip: 'Log out',
              onPressed: widget.onLogout),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: load,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  OutlinedButton.icon(
                    onPressed: pickDate,
                    icon: const Icon(Icons.calendar_today),
                    label: Text(isToday
                        ? 'Today, ${prettyDate(date)}'
                        : prettyDate(date)),
                  ),
                  const SizedBox(height: 14),
                  if (current != null)
                    Card(
                      color: statusColor(current!['display_status'])
                          .withOpacity(0.12),
                      child: ListTile(
                        leading: CircleAvatar(
                            backgroundColor:
                                statusColor(current!['display_status']),
                            radius: 8),
                        title: Text(statusLabel(current!),
                            style:
                                const TextStyle(fontWeight: FontWeight.w600)),
                        subtitle: Text(current!['updated_at_label'] != null
                            ? 'Last updated ${current!['updated_at_label']}'
                            : 'You have not set your status for this date'),
                        trailing: canExtend
                            ? TextButton(
                                onPressed: extend, child: const Text('+1 hr'))
                            : null,
                      ),
                    ),
                  if (video != null) videoCard(),
                  if (canComplete) ...[
                    const SizedBox(height: 8),
                    SizedBox(
                      height: 56,
                      child: FilledButton.icon(
                        style: FilledButton.styleFrom(
                            backgroundColor: Colors.teal),
                        onPressed: completeVideo,
                        icon: const Icon(Icons.check_circle),
                        label: const Text('Video complete',
                            style: TextStyle(fontSize: 18)),
                      ),
                    ),
                  ],
                  const SizedBox(height: 18),
                  const Text('Set your status',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                  if (videoLocked)
                    const Padding(
                      padding: EdgeInsets.only(top: 6),
                      child: Text(
                        'Locked while a video is assigned or in progress. Use "Video started" / "Video complete" above.',
                        style: TextStyle(color: Colors.grey),
                      ),
                    ),
                  const SizedBox(height: 10),
                  statusBtn('available', 'Available', Icons.check_circle,
                      Colors.green),
                  statusBtn(
                      'unavailable', 'Unavailable', Icons.cancel, Colors.red),
                  statusBtn('working_on_video', 'Working on a video',
                      Icons.videocam, Colors.amber.shade800),
                  if (status == 'available' || status == 'unavailable') ...[
                    const SizedBox(height: 8),
                    Text(
                        status == 'available'
                            ? 'Available till (optional)'
                            : 'Unavailable till (optional, default all day)',
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 8),
                    timeChips(),
                  ],
                  const SizedBox(height: 20),
                  SizedBox(
                    height: 52,
                    child: FilledButton(
                      onPressed: (saving || videoLocked) ? null : save,
                      child: saving
                          ? const SizedBox(
                              height: 22,
                              width: 22,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white))
                          : const Text('Save', style: TextStyle(fontSize: 18)),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}

// ---------------------------------------------------------------
// USER: messages from admin
// ---------------------------------------------------------------
class MessagesPage extends StatefulWidget {
  const MessagesPage({super.key});

  @override
  State<MessagesPage> createState() => _MessagesPageState();
}

class _MessagesPageState extends State<MessagesPage> {
  List<Map<String, dynamic>> msgs = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = await Api.get('/me/messages');
      msgs = (r['messages'] as List)
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
      await setSeen((r['latest_id'] as int?) ?? 0);
    } catch (e) {
      if (mounted) toast(context, errMsg(e));
    }
    if (mounted) setState(() => loading = false);
  }

  IconData iconFor(String kind) {
    switch (kind) {
      case 'assignment':
        return Icons.videocam;
      case 'reminder':
        return Icons.alarm;
      case 'announcement':
        return Icons.campaign;
      default:
        return Icons.info_outline;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Messages')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: load,
              child: msgs.isEmpty
                  ? ListView(children: const [
                      SizedBox(height: 120),
                      Center(child: Text('No messages yet'))
                    ])
                  : ListView.builder(
                      padding: const EdgeInsets.all(12),
                      itemCount: msgs.length,
                      itemBuilder: (_, i) {
                        final m = msgs[i];
                        return Card(
                          child: ListTile(
                            leading:
                                Icon(iconFor(m['kind']), color: Colors.indigo),
                            title: Text(m['body']),
                            subtitle: Text(m['created_at_label'] ?? ''),
                          ),
                        );
                      },
                    ),
            ),
    );
  }
}

// ---------------------------------------------------------------
// ADMIN: home with 3 tabs (dashboard, messages, users)
// ---------------------------------------------------------------
class AdminHome extends StatefulWidget {
  final VoidCallback onLogout;
  const AdminHome({super.key, required this.onLogout});

  @override
  State<AdminHome> createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> {
  int tab = 0;
  static const titles = ['Team availability', 'Send message', 'Manage users'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(titles[tab]),
        actions: [
          IconButton(
              icon: const Icon(Icons.logout),
              tooltip: 'Log out',
              onPressed: widget.onLogout),
        ],
      ),
      body: IndexedStack(
        index: tab,
        children: const [DashboardPage(), AdminMessagesPage(), UsersPage()],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.dashboard), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.campaign), label: 'Messages'),
          NavigationDestination(icon: Icon(Icons.people), label: 'Users'),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------
// ADMIN: dashboard (queue order, auto refresh every 20 s)
// ---------------------------------------------------------------
class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  DateTime date = DateTime.now();
  String filter =
      'all'; // all | available_now | not_responded | needs_assistance
  Map<String, dynamic>? data;
  bool loading = true;
  Timer? timer;
  Set<int> prevNeed = {};
  bool firstLoad = true;

  @override
  void initState() {
    super.initState();
    load();
    timer = Timer.periodic(const Duration(seconds: 20), (_) {
      if (mounted) load(quiet: true);
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> load({bool quiet = false}) async {
    if (!quiet) setState(() => loading = true);
    try {
      final r = await Api.get(
          '/admin/availability?date=${apiDate(date)}&filter=$filter');
      data = Map<String, dynamic>.from(r);
      final users = (data!['users'] as List);
      final need = users
          .where((u) => u['needs_assistance'] == true)
          .map<int>((u) => u['user_id'] as int)
          .toSet();
      final fresh = need.difference(prevNeed);
      if (!firstLoad && fresh.isNotEmpty && mounted) {
        final names = users
            .where((u) => fresh.contains(u['user_id']))
            .map((u) => u['name'])
            .join(', ');
        toast(context, 'Need assistance: $names');
      }
      prevNeed = need;
      firstLoad = false;
    } catch (e) {
      if (!quiet && mounted) toast(context, errMsg(e));
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> pickDate() async {
    final now = DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: date,
      firstDate: now.subtract(const Duration(days: 60)),
      lastDate: now.add(const Duration(days: 60)),
    );
    if (d != null) {
      date = d;
      load();
    }
  }

  void shiftDay(int n) {
    date = date.add(Duration(days: n));
    load();
  }

  Future<void> openProfile(Map<String, dynamic> u) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (_) => AdminUserProfilePage(
              userId: u['user_id'] as int, name: u['name'] as String)),
    );
    load(quiet: true);
  }

  Widget filterChip(String key, String label) => ChoiceChip(
        label: Text(label),
        selected: filter == key,
        onSelected: (_) {
          filter = key;
          load();
        },
      );

  Widget countPill(String text, Color color) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: color.withOpacity(0.14),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(text,
            style: TextStyle(color: color, fontWeight: FontWeight.w600)),
      );

  Widget userCard(Map<String, dynamic> u) {
    final String ds = u['display_status'];
    final color = statusColor(ds);
    final Map? asg = u['assignment'] as Map?;
    final bool needs = u['needs_assistance'] == true;
    final int done = (u['videos_done'] as int?) ?? 0;
    final qp = u['queue_position'];
    final String name = u['name'] as String;
    return Card(
      shape: needs
          ? RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: const BorderSide(color: Colors.red, width: 2))
          : null,
      child: ListTile(
        onTap: () => openProfile(u),
        leading: CircleAvatar(
          backgroundColor: color,
          child: Text(
            qp != null ? '#$qp' : (name.isEmpty ? '?' : name[0].toUpperCase()),
            style: const TextStyle(
                color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
          ),
        ),
        title: Text(name, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(statusLabel(u),
                style: TextStyle(color: color, fontWeight: FontWeight.w500)),
            if (asg != null)
              Text(
                  '${asg['server']} - ${asg['part_label']}'
                  '${asg['waiting_minutes'] != null ? ' - waiting ${asg['waiting_minutes']} min' : ''}',
                  style: const TextStyle(fontSize: 12)),
            if (needs)
              const Text('Need assistance',
                  style: TextStyle(
                      color: Colors.red, fontWeight: FontWeight.bold)),
            if (done > 0)
              Text(
                  'Videos done today: $done'
                  '${u['last_completed_label'] != null ? ' (last ${u['last_completed_label']})' : ''}',
                  style: const TextStyle(fontSize: 12, color: Colors.grey)),
          ],
        ),
        trailing: u['updated_at_label'] != null
            ? Text('Updated\n${u['updated_at_label']}',
                textAlign: TextAlign.right,
                style: const TextStyle(fontSize: 11, color: Colors.grey))
            : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final counts = (data?['counts'] as Map?) ?? {};
    final users = (data?['users'] as List?) ?? [];
    final needCount = (counts['needs_assistance'] ?? 0) as int;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                  icon: const Icon(Icons.chevron_left),
                  onPressed: () => shiftDay(-1)),
              TextButton.icon(
                onPressed: pickDate,
                icon: const Icon(Icons.calendar_today, size: 18),
                label: Text(isSameDay(date, DateTime.now())
                    ? 'Today, ${prettyDate(date)}'
                    : prettyDate(date)),
              ),
              IconButton(
                  icon: const Icon(Icons.chevron_right),
                  onPressed: () => shiftDay(1)),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Wrap(
            spacing: 8,
            children: [
              filterChip('all', 'All'),
              filterChip('available_now', 'Available now'),
              filterChip('not_responded', 'Not responded'),
              filterChip('needs_assistance', 'Needs assistance'),
            ],
          ),
        ),
        if (data != null)
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
            child: Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                countPill(
                    '${counts['available'] ?? 0} available', Colors.green),
                countPill(
                    '${counts['video_assigned'] ?? 0} assigned', Colors.indigo),
                countPill('${counts['working_on_video'] ?? 0} on video',
                    Colors.amber.shade800),
                countPill(
                    '${counts['unavailable'] ?? 0} unavailable', Colors.red),
                countPill('${counts['not_responded'] ?? 0} no reply',
                    Colors.blueGrey),
                if (needCount > 0)
                  countPill('$needCount need help', Colors.red),
              ],
            ),
          ),
        const SizedBox(height: 4),
        Expanded(
          child: loading
              ? const Center(child: CircularProgressIndicator())
              : RefreshIndicator(
                  onRefresh: load,
                  child: users.isEmpty
                      ? ListView(children: const [
                          SizedBox(height: 120),
                          Center(child: Text('No users to show')),
                        ])
                      : ListView.builder(
                          padding: const EdgeInsets.fromLTRB(12, 4, 12, 16),
                          itemCount: users.length,
                          itemBuilder: (_, i) =>
                              userCard(Map<String, dynamic>.from(users[i])),
                        ),
                ),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------
// ADMIN: one user's profile (assign, take back, remind)
// ---------------------------------------------------------------
class AdminUserProfilePage extends StatefulWidget {
  final int userId;
  final String name;
  const AdminUserProfilePage(
      {super.key, required this.userId, required this.name});

  @override
  State<AdminUserProfilePage> createState() => _AdminUserProfilePageState();
}

class _AdminUserProfilePageState extends State<AdminUserProfilePage> {
  Map<String, dynamic>? data;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = await Api.get('/admin/users/${widget.userId}/profile');
      data = Map<String, dynamic>.from(r);
    } catch (e) {
      if (mounted) toast(context, errMsg(e));
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> assign() async {
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (_) => AssignSheet(userId: widget.userId, name: widget.name),
    );
    if (ok == true) {
      if (mounted) toast(context, 'Video assigned. User notified');
      load();
    }
  }

  Future<void> takeBack(int id) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Take back this video?'),
        content: Text(
            '${widget.name} will be notified. You can then assign it to someone else.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          FilledButton(
              style: FilledButton.styleFrom(backgroundColor: Colors.red),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Take back')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Api.post('/admin/assignments/$id/cancel');
      if (mounted) toast(context, 'Assignment taken back');
      load();
    } catch (e) {
      if (mounted) toast(context, errMsg(e));
    }
  }

  Future<void> remind() async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Remind ${widget.name}'),
        content: TextField(
          controller: c,
          maxLines: 2,
          decoration: const InputDecoration(
              hintText: 'Leave empty for the default reminder',
              border: OutlineInputBorder()),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Send')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Api.post(
          '/admin/users/${widget.userId}/remind', {'message': c.text.trim()});
      if (mounted) toast(context, 'Reminder sent');
    } catch (e) {
      if (mounted) toast(context, errMsg(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final avail =
        data == null ? null : Map<String, dynamic>.from(data!['availability']);
    final Map? active = data?['active_assignment'] as Map?;
    final recent = (data?['recent_assignments'] as List?) ?? [];

    return Scaffold(
      appBar: AppBar(title: Text(widget.name)),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: load,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  if (avail != null)
                    Card(
                      color: statusColor(avail['display_status'])
                          .withOpacity(0.12),
                      child: ListTile(
                        leading: CircleAvatar(
                            backgroundColor:
                                statusColor(avail['display_status']),
                            radius: 8),
                        title: Text(statusLabel(avail),
                            style:
                                const TextStyle(fontWeight: FontWeight.w600)),
                        subtitle: Text(avail['updated_at_label'] != null
                            ? 'Last updated ${avail['updated_at_label']}'
                            : 'Has not set status today'),
                      ),
                    ),
                  if (active != null)
                    Card(
                      shape: active['needs_assistance'] == true
                          ? RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side:
                                  const BorderSide(color: Colors.red, width: 2))
                          : null,
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                                active['status'] == 'assigned'
                                    ? 'Video assigned - not started'
                                    : 'Video in progress',
                                style: const TextStyle(
                                    fontSize: 17, fontWeight: FontWeight.bold)),
                            const SizedBox(height: 6),
                            Text('Server: ${active['server']}'),
                            Text('Time: ${active['part_label']}'),
                            if ((active['note'] ?? '').toString().isNotEmpty)
                              Text('Note: ${active['note']}'),
                            Text('Assigned at ${active['assigned_at_label']}'),
                            if (active['status'] == 'started')
                              Text('Started at ${active['started_at_label']}'),
                            if (active['needs_assistance'] == true)
                              Padding(
                                padding: const EdgeInsets.only(top: 8),
                                child: Text(
                                    'Need assistance: not started for ${active['waiting_minutes']} min',
                                    style: const TextStyle(
                                        color: Colors.red,
                                        fontWeight: FontWeight.bold)),
                              ),
                            if (active['status'] == 'assigned') ...[
                              const SizedBox(height: 10),
                              OutlinedButton.icon(
                                style: OutlinedButton.styleFrom(
                                    foregroundColor: Colors.red),
                                onPressed: () => takeBack(active['id'] as int),
                                icon: const Icon(Icons.undo),
                                label: const Text('Take back this video'),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                  const SizedBox(height: 8),
                  SizedBox(
                    height: 52,
                    child: FilledButton.icon(
                      onPressed: active == null ? assign : null,
                      icon: const Icon(Icons.assignment_ind),
                      label: Text(
                          active == null
                              ? 'Assign a video'
                              : 'Already has an active video',
                          style: const TextStyle(fontSize: 17)),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 48,
                    child: OutlinedButton.icon(
                      onPressed: remind,
                      icon: const Icon(Icons.alarm),
                      label: const Text('Send reminder'),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text('Recent videos',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                  if (recent.isEmpty)
                    const Padding(
                      padding: EdgeInsets.only(top: 8),
                      child: Text('No videos yet',
                          style: TextStyle(color: Colors.grey)),
                    ),
                  for (final a in recent)
                    ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      title: Text('${a['server']} - ${a['part_label']}'),
                      subtitle: Text(
                          '${a['status']} - assigned ${a['assigned_at_label']}'
                          '${a['completed_at_label'] != null ? ', completed ${a['completed_at_label']}' : ''}'),
                    ),
                ],
              ),
            ),
    );
  }
}

class AssignSheet extends StatefulWidget {
  final int userId;
  final String name;
  const AssignSheet({super.key, required this.userId, required this.name});

  @override
  State<AssignSheet> createState() => _AssignSheetState();
}

class _AssignSheetState extends State<AssignSheet> {
  String server = 'eu';
  String part = 'full';
  final noteC = TextEditingController();
  bool sending = false;
  String? error;

  Future<void> submit() async {
    setState(() {
      sending = true;
      error = null;
    });
    try {
      await Api.post('/admin/users/${widget.userId}/assign',
          {'server': server, 'part': part, 'note': noteC.text.trim()});
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        setState(() {
          sending = false;
          error = errMsg(e);
        });
      }
    }
  }

  Widget choice(String value, String label, String groupValue,
          void Function(String) onPick) =>
      ChoiceChip(
        label: Text(label),
        selected: groupValue == value,
        onSelected: (_) => onPick(value),
      );

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
          16, 16, 16, 16 + MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Assign a video to ${widget.name}',
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            const Text('Server', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            Wrap(spacing: 8, children: [
              choice('eu', 'EU', server, (v) => setState(() => server = v)),
              choice('us', 'US', server, (v) => setState(() => server = v)),
            ]),
            const SizedBox(height: 16),
            const Text('Time', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            Wrap(spacing: 8, children: [
              choice(
                  'full', 'Full video', part, (v) => setState(() => part = v)),
              choice('first_half', 'First half', part,
                  (v) => setState(() => part = v)),
              choice('second_half', 'Second half', part,
                  (v) => setState(() => part = v)),
            ]),
            const SizedBox(height: 16),
            TextField(
              controller: noteC,
              maxLines: 3,
              decoration: const InputDecoration(
                  labelText: 'Note (optional instructions)',
                  border: OutlineInputBorder()),
            ),
            if (error != null) ...[
              const SizedBox(height: 8),
              Text(error!, style: const TextStyle(color: Colors.red)),
            ],
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: FilledButton(
                onPressed: sending ? null : submit,
                child: sending
                    ? const SizedBox(
                        height: 22,
                        width: 22,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white))
                    : const Text('Assign', style: TextStyle(fontSize: 17)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------
// ADMIN: send announcements to everyone
// ---------------------------------------------------------------
class AdminMessagesPage extends StatefulWidget {
  const AdminMessagesPage({super.key});

  @override
  State<AdminMessagesPage> createState() => _AdminMessagesPageState();
}

class _AdminMessagesPageState extends State<AdminMessagesPage> {
  final c = TextEditingController();
  List<Map<String, dynamic>> sent = [];
  bool sending = false;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = await Api.get('/admin/messages');
      sent = (r['messages'] as List)
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    } catch (e) {
      if (mounted) toast(context, errMsg(e));
    }
    if (mounted) setState(() {});
  }

  Future<void> send() async {
    final text = c.text.trim();
    if (text.isEmpty) {
      toast(context, 'Write a message first');
      return;
    }
    setState(() => sending = true);
    try {
      await Api.post('/admin/messages', {'message': text});
      c.clear();
      if (mounted) toast(context, 'Sent to everyone');
      await load();
    } catch (e) {
      if (mounted) toast(context, errMsg(e));
    }
    if (mounted) setState(() => sending = false);
  }

  @override
  Widget build(BuildContext context) {
    const quick = [
      'Everyone update your availability',
      'Important: please check the app',
    ];
    return RefreshIndicator(
      onRefresh: load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Message to everyone',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: [
              for (final q in quick)
                ActionChip(
                    label: Text(q),
                    onPressed: () => setState(() => c.text = q)),
            ],
          ),
          const SizedBox(height: 8),
          TextField(
            controller: c,
            maxLines: 3,
            decoration: const InputDecoration(
                hintText: 'Write an important message...',
                border: OutlineInputBorder()),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 48,
            child: FilledButton.icon(
              onPressed: sending ? null : send,
              icon: const Icon(Icons.send),
              label: const Text('Send to everyone'),
            ),
          ),
          const SizedBox(height: 20),
          const Text('Sent messages',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          if (sent.isEmpty)
            const Padding(
              padding: EdgeInsets.only(top: 8),
              child: Text('Nothing sent yet',
                  style: TextStyle(color: Colors.grey)),
            ),
          for (final m in sent)
            Card(
              child: ListTile(
                leading: const Icon(Icons.campaign, color: Colors.indigo),
                title: Text(m['body']),
                subtitle: Text(m['created_at_label'] ?? ''),
              ),
            ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------
// ADMIN: manage users (add, reset password, delete)
// ---------------------------------------------------------------
class UsersPage extends StatefulWidget {
  const UsersPage({super.key});

  @override
  State<UsersPage> createState() => _UsersPageState();
}

class _UsersPageState extends State<UsersPage> {
  List users = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() => loading = true);
    try {
      users = await Api.get('/admin/users');
    } catch (e) {
      if (mounted) toast(context, errMsg(e));
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> addUser() async {
    final nameC = TextEditingController();
    final userC = TextEditingController();
    final passC = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Add user'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                  controller: nameC,
                  decoration: const InputDecoration(labelText: 'Full name')),
              TextField(
                  controller: userC,
                  autocorrect: false,
                  decoration: const InputDecoration(labelText: 'Username')),
              TextField(
                  controller: passC,
                  decoration:
                      const InputDecoration(labelText: 'Password (min 6)')),
            ],
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Create')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Api.post('/admin/users', {
        'name': nameC.text.trim(),
        'username': userC.text.trim(),
        'password': passC.text,
        'role': 'user',
      });
      if (mounted) toast(context, 'User created');
      load();
    } catch (e) {
      if (mounted) toast(context, errMsg(e));
    }
  }

  Future<void> resetPassword(Map u) async {
    final passC = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('New password for ${u['name']}'),
        content: TextField(
            controller: passC,
            decoration:
                const InputDecoration(labelText: 'New password (min 6)')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Reset')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Api.post('/admin/users/${u['id']}/reset-password',
          {'new_password': passC.text});
      if (mounted) toast(context, 'Password reset');
    } catch (e) {
      if (mounted) toast(context, errMsg(e));
    }
  }

  Future<void> deleteUser(Map u) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Delete ${u['name']}?'),
        content: const Text(
            'This also deletes their availability and video history.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          FilledButton(
              style: FilledButton.styleFrom(backgroundColor: Colors.red),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Delete')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Api.delete('/admin/users/${u['id']}');
      if (mounted) toast(context, 'User deleted');
      load();
    } catch (e) {
      if (mounted) toast(context, errMsg(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: addUser,
        icon: const Icon(Icons.person_add),
        label: const Text('Add user'),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: load,
              child: ListView.builder(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 90),
                itemCount: users.length,
                itemBuilder: (_, i) {
                  final u = Map<String, dynamic>.from(users[i]);
                  final isMe = u['id'] == Api.user?['id'];
                  return Card(
                    child: ListTile(
                      leading: const CircleAvatar(child: Icon(Icons.person)),
                      title: Text(u['name']),
                      subtitle: Text('@${u['username']} - ${u['role']}'),
                      onTap: u['role'] == 'user'
                          ? () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => AdminUserProfilePage(
                                        userId: u['id'] as int,
                                        name: u['name'] as String)),
                              )
                          : null,
                      trailing: isMe
                          ? null
                          : PopupMenuButton<String>(
                              onSelected: (v) => v == 'reset'
                                  ? resetPassword(u)
                                  : deleteUser(u),
                              itemBuilder: (_) => const [
                                PopupMenuItem(
                                    value: 'reset',
                                    child: Text('Reset password')),
                                PopupMenuItem(
                                    value: 'delete',
                                    child: Text('Delete user')),
                              ],
                            ),
                    ),
                  );
                },
              ),
            ),
    );
  }
}
